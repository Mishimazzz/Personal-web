1）The harpoons are fired in groups of four. After a group is fired, there will be a reload. 

2) The up and down arrow keys can be used to adjust the harpoon's firing angle, and the harpoon is fired by pressing the space bar.